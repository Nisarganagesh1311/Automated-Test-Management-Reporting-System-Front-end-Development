'use client';

import { useState } from 'react';
import { Bell, CheckCircle2, AlertCircle, Loader2 } from 'lucide-react';
import { testNotification } from '@/lib/api';

type NotifState = 'idle' | 'loading' | 'success' | 'error';

function WebhookSection({
  title,
  icon,
  type,
  placeholder,
}: {
  title: string;
  icon: React.ReactNode;
  type: 'slack' | 'teams';
  placeholder: string;
}) {
  const [url,   setUrl]   = useState('');
  const [state, setState] = useState<NotifState>('idle');
  const [msg,   setMsg]   = useState('');

  async function handleTest() {
    if (!url.trim()) return;
    setState('loading');
    try {
      await testNotification(type, url.trim());
      setState('success');
      setMsg('Notification sent successfully!');
    } catch (err: any) {
      setState('error');
      setMsg(err?.response?.data?.detail || 'Failed to send notification.');
    }
  }

  return (
    <div className="rounded-xl border border-slate-700 bg-slate-800/60 p-5">
      <div className="flex items-center gap-2 mb-4">
        {icon}
        <h3 className="font-semibold text-white">{title}</h3>
      </div>
      <div className="space-y-3">
        <div>
          <label className="block text-xs font-medium text-slate-400 mb-1">Webhook URL</label>
          <input
            type="url"
            value={url}
            onChange={(e) => { setUrl(e.target.value); setState('idle'); }}
            placeholder={placeholder}
            className="w-full px-3 py-2.5 rounded-lg bg-slate-700/50 border border-slate-600 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-sky-500 transition-colors"
          />
        </div>
        <button
          onClick={handleTest}
          disabled={!url.trim() || state === 'loading'}
          className="flex items-center gap-2 px-4 py-2 rounded-lg bg-sky-500/20 border border-sky-500/40 text-sky-400 hover:bg-sky-500/30 text-sm font-medium transition-colors disabled:opacity-50"
        >
          {state === 'loading' ? <Loader2 className="w-4 h-4 animate-spin" /> : <Bell className="w-4 h-4" />}
          Send Test Notification
        </button>
        {state !== 'idle' && state !== 'loading' && (
          <div className={`flex items-center gap-2 text-sm ${state === 'success' ? 'text-emerald-400' : 'text-red-400'}`}>
            {state === 'success' ? <CheckCircle2 className="w-4 h-4" /> : <AlertCircle className="w-4 h-4" />}
            {msg}
          </div>
        )}
      </div>
    </div>
  );
}

export default function SettingsPage() {
  return (
    <div className="max-w-2xl mx-auto space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-white">Settings</h1>
        <p className="text-slate-400 text-sm mt-1">Configure notifications and integrations</p>
      </div>

      {/* Notifications */}
      <section>
        <h2 className="text-base font-semibold text-slate-300 mb-3 flex items-center gap-2">
          <Bell className="w-4 h-4 text-sky-400" /> Notifications
        </h2>
        <div className="space-y-4">
          <WebhookSection
            title="Slack"
            icon={<div className="w-7 h-7 rounded bg-[#4A154B] flex items-center justify-center text-white text-xs font-bold">S</div>}
            type="slack"
            placeholder="https://hooks.slack.com/services/…"
          />
          <WebhookSection
            title="Microsoft Teams"
            icon={<div className="w-7 h-7 rounded bg-blue-600 flex items-center justify-center text-white text-xs font-bold">T</div>}
            type="teams"
            placeholder="https://your-org.webhook.office.com/webhookb2/…"
          />
        </div>
      </section>

      {/* CI/CD Instructions */}
      <section className="rounded-xl border border-slate-700 bg-slate-800/60 p-5">
        <h2 className="font-semibold text-white mb-3">CI/CD Integration</h2>
        <p className="text-sm text-slate-400 mb-4">
          Add the following step to your GitHub Actions workflow to upload test results automatically:
        </p>
        <pre className="bg-slate-900 rounded-lg p-4 text-xs text-slate-300 overflow-x-auto font-mono leading-relaxed whitespace-pre">
          {[
            '- name: Upload Test Results',
            '  if: always()',
            '  run: |',
            '    curl -X POST "${{ vars.TESTFLOW_API_URL }}/api/upload" \\',
            '      -F "file=@test-results.xml" \\',
            '      -F "source_type=junit" \\',
            '      -F "name=${{ github.workflow }} #${{ github.run_number }}" \\',
            '      -F "branch=${{ github.ref_name }}" \\',
            '      -F "commit_hash=${{ github.sha }}" \\',
            '      -F "project=${{ github.repository }}" \\',
            '      -F "notify_slack=true"',
          ].join('\n')}
        </pre>
      </section>
    </div>
  );
}
