'use client';

import { useEffect, useState } from 'react';
import { Activity, CheckCircle2, XCircle, Clock, TrendingUp } from 'lucide-react';
import { StatsCard } from '@/components/dashboard/StatsCard';
import { RecentRuns } from '@/components/dashboard/RecentRuns';
import { FailureTrendChart } from '@/components/charts/FailureTrendChart';
import { PassRateChart } from '@/components/charts/PassRateChart';
import { getAnalyticsSummary, getTestRuns, getTrends } from '@/lib/api';
import type { AnalyticsSummary, TestRun, TrendPoint } from '@/types';

export default function DashboardPage() {
  const [summary, setSummary]   = useState<AnalyticsSummary | null>(null);
  const [runs,    setRuns]     = useState<TestRun[]>([]);
  const [trends,  setTrends]   = useState<TrendPoint[]>([]);
  const [loading, setLoading]  = useState(true);

  useEffect(() => {
    Promise.all([
      getAnalyticsSummary(),
      getTestRuns(1, 8),
      getTrends(30),
    ])
      .then(([s, r, t]) => {
        setSummary(s);
        setRuns(r.items);
        setTrends(t);
      })
      .catch(console.error)
      .finally(() => setLoading(false));
  }, []);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin w-8 h-8 rounded-full border-2 border-sky-500 border-t-transparent" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-white">Dashboard</h1>
        <p className="text-slate-400 text-sm mt-1">Overview of all test activity</p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatsCard
          title="Total Runs"
          value={summary?.total_runs ?? 0}
          icon={Activity}
          color="sky"
          subtitle="All time"
        />
        <StatsCard
          title="Total Tests"
          value={(summary?.total_tests ?? 0).toLocaleString()}
          icon={CheckCircle2}
          color="purple"
          subtitle="Across all runs"
        />
        <StatsCard
          title="Pass Rate"
          value={`${summary?.overall_pass_rate.toFixed(1) ?? 0}%`}
          icon={TrendingUp}
          color="green"
          subtitle="Overall"
        />
        <StatsCard
          title="Failed Today"
          value={summary?.failed_runs_today ?? 0}
          icon={XCircle}
          color="red"
          subtitle="Runs with failures"
        />
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <FailureTrendChart data={trends} />
        </div>
        <div>
          {summary && <PassRateChart summary={summary} />}
        </div>
      </div>

      {/* Recent Runs */}
      <RecentRuns runs={runs} />
    </div>
  );
}
