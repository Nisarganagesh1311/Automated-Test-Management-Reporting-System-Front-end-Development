'use client';

import { useEffect, useState } from 'react';
import { useParams, useRouter } from 'next/navigation';
import Link from 'next/link';
import {
  ArrowLeft, CheckCircle2, XCircle, Clock, GitBranch,
  GitCommit, Bot, AlertTriangle, SkipForward,
} from 'lucide-react';
import { format } from 'date-fns';
import { clsx } from 'clsx';
import { getTestRun, deleteTestRun } from '@/lib/api';
import { TestCaseTable } from '@/components/test-runs/TestCaseTable';
import type { TestRunDetail } from '@/types';

function StatBadge({ count, label, color }: { count: number; label: string; color: string }) {
  return (
    <div className={clsx('flex-1 rounded-xl p-4 text-center', color)}>
      <p className="text-2xl font-bold text-white">{count}</p>
      <p className="text-xs text-slate-400 mt-0.5">{label}</p>
    </div>
  );
}

export default function TestRunDetailPage() {
  const { id } = useParams<{ id: string }>();
  const router  = useRouter();
  const [run,     setRun]     = useState<TestRunDetail | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    getTestRun(id)
      .then(setRun)
      .catch(console.error)
      .finally(() => setLoading(false));
  }, [id]);

  async function handleDelete() {
    if (!confirm('Delete this test run permanently?')) return;
    await deleteTestRun(id);
    router.push('/test-runs');
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin w-8 h-8 rounded-full border-2 border-sky-500 border-t-transparent" />
      </div>
    );
  }

  if (!run) return <div className="text-slate-400 p-6">Test run not found.</div>;

  const passRate = run.total_tests > 0 ? ((run.passed_tests / run.total_tests) * 100).toFixed(1) : '0';

  return (
    <div className="space-y-6">

      {/* Header */}
      <div className="flex items-start justify-between gap-4">
        <div>
          <Link href="/test-runs" className="flex items-center gap-1.5 text-sm text-slate-400 hover:text-slate-200 transition-colors mb-3">
            <ArrowLeft className="w-4 h-4" /> Back to Test Runs
          </Link>
          <div className="flex items-center gap-3">
            {run.status === 'passed'
              ? <CheckCircle2 className="w-7 h-7 text-emerald-400" />
              : <XCircle className="w-7 h-7 text-red-400" />
            }
            <h1 className="text-2xl font-bold text-white">{run.name}</h1>
          </div>
          <div className="flex items-center gap-4 mt-2 flex-wrap text-sm text-slate-400">
            {run.project    && <span className="font-medium text-slate-300">{run.project}</span>}
            {run.branch     && <span className="flex items-center gap-1"><GitBranch className="w-3.5 h-3.5" /> {run.branch}</span>}
            {run.commit_hash && <span className="flex items-center gap-1"><GitCommit className="w-3.5 h-3.5" /> {run.commit_hash.slice(0, 7)}</span>}
            <span className="flex items-center gap-1"><Clock className="w-3.5 h-3.5" /> {format(new Date(run.created_at), 'MMM d, yyyy HH:mm')}</span>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <div className="text-right">
            <p className={clsx('text-4xl font-bold', Number(passRate) >= 80 ? 'text-emerald-400' : Number(passRate) >= 50 ? 'text-amber-400' : 'text-red-400')}>
              {passRate}%
            </p>
            <p className="text-xs text-slate-500">pass rate</p>
          </div>
        </div>
      </div>

      {/* Counts */}
      <div className="flex gap-3">
        <StatBadge count={run.total_tests}   label="Total"   color="bg-slate-700/60 border border-slate-600" />
        <StatBadge count={run.passed_tests}  label="Passed"  color="bg-emerald-500/10 border border-emerald-500/20" />
        <StatBadge count={run.failed_tests}  label="Failed"  color="bg-red-500/10 border border-red-500/20" />
        <StatBadge count={run.skipped_tests} label="Skipped" color="bg-amber-500/10 border border-amber-500/20" />
      </div>

      {/* AI Summary */}
      {run.ai_summary && (
        <div className="rounded-xl border border-purple-500/30 bg-purple-500/5 p-5">
          <div className="flex items-center gap-2 mb-3">
            <Bot className="w-5 h-5 text-purple-400" />
            <h3 className="font-semibold text-purple-300">AI Failure Analysis</h3>
          </div>
          <p className="text-sm text-slate-300 leading-relaxed whitespace-pre-line">{run.ai_summary}</p>
        </div>
      )}

      {/* Duration & metadata */}
      <div className="grid grid-cols-3 gap-4 text-sm">
        <div className="rounded-lg border border-slate-700 bg-slate-800/60 p-4">
          <p className="text-slate-400 text-xs mb-1">Duration</p>
          <p className="text-white font-semibold">{run.duration.toFixed(2)}s</p>
        </div>
        <div className="rounded-lg border border-slate-700 bg-slate-800/60 p-4">
          <p className="text-slate-400 text-xs mb-1">Source</p>
          <p className="text-white font-semibold capitalize">{run.source_type}</p>
        </div>
        <div className="rounded-lg border border-slate-700 bg-slate-800/60 p-4">
          <p className="text-slate-400 text-xs mb-1">Status</p>
          <p className={clsx('font-semibold capitalize', run.status === 'passed' ? 'text-emerald-400' : 'text-red-400')}>
            {run.status}
          </p>
        </div>
      </div>

      {/* Test Cases */}
      <div>
        <h2 className="text-lg font-semibold text-white mb-3">Test Cases ({run.test_cases.length})</h2>
        <TestCaseTable cases={run.test_cases} />
      </div>

      {/* Danger Zone */}
      <div className="rounded-xl border border-red-500/20 bg-red-500/5 p-5 flex items-center justify-between">
        <div>
          <p className="font-medium text-red-400">Delete Test Run</p>
          <p className="text-xs text-slate-400 mt-0.5">This will permanently remove this run and all its test cases.</p>
        </div>
        <button
          onClick={handleDelete}
          className="px-4 py-2 rounded-lg bg-red-500/20 border border-red-500/40 text-red-400 hover:bg-red-500/30 text-sm font-medium transition-colors"
        >
          Delete Run
        </button>
      </div>
    </div>
  );
}
