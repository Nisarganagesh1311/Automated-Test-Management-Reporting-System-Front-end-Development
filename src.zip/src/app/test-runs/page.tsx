'use client';

import { useEffect, useState, useCallback } from 'react';
import { Search, RefreshCw, Filter } from 'lucide-react';
import { TestRunCard } from '@/components/test-runs/TestRunCard';
import { getTestRuns, deleteTestRun } from '@/lib/api';
import type { TestRun } from '@/types';

const STATUS_OPTIONS = [
  { value: '',       label: 'All Statuses' },
  { value: 'passed', label: 'Passed' },
  { value: 'failed', label: 'Failed' },
];

export default function TestRunsPage() {
  const [runs,     setRuns]     = useState<TestRun[]>([]);
  const [search,   setSearch]   = useState('');
  const [status,   setStatus]   = useState('');
  const [page,     setPage]     = useState(1);
  const [total,    setTotal]    = useState(0);
  const [pages,    setPages]    = useState(1);
  const [loading,  setLoading]  = useState(true);

  const PAGE_SIZE = 12;

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const data = await getTestRuns(page, PAGE_SIZE, undefined, status || undefined);
      setRuns(data.items);
      setTotal(data.total);
      setPages(data.total_pages);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  }, [page, status]);

  useEffect(() => { load(); }, [load]);

  async function handleDelete(id: string) {
    if (!confirm('Delete this test run? This cannot be undone.')) return;
    await deleteTestRun(id);
    load();
  }

  const filteredRuns = search
    ? runs.filter((r) =>
        r.name.toLowerCase().includes(search.toLowerCase()) ||
        r.project?.toLowerCase().includes(search.toLowerCase()) ||
        r.branch?.toLowerCase().includes(search.toLowerCase()),
      )
    : runs;

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">Test Runs</h1>
          <p className="text-slate-400 text-sm mt-1">{total} total runs</p>
        </div>
        <button onClick={load} className="flex items-center gap-2 px-4 py-2 rounded-lg border border-slate-600 text-slate-300 hover:border-slate-400 text-sm transition-colors">
          <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
          Refresh
        </button>
      </div>

      {/* Filters */}
      <div className="flex items-center gap-3">
        <div className="relative flex-1 max-w-sm">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search runs, projects, branches…"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-9 pr-3 py-2 rounded-lg bg-slate-700/50 border border-slate-600 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-sky-500 transition-colors"
          />
        </div>
        <div className="flex items-center gap-2">
          <Filter className="w-4 h-4 text-slate-400" />
          <select
            value={status}
            onChange={(e) => { setStatus(e.target.value); setPage(1); }}
            className="px-3 py-2 rounded-lg bg-slate-700/50 border border-slate-600 text-sm text-white focus:outline-none focus:border-sky-500 transition-colors"
          >
            {STATUS_OPTIONS.map((o) => (
              <option key={o.value} value={o.value}>{o.label}</option>
            ))}
          </select>
        </div>
      </div>

      {loading ? (
        <div className="flex items-center justify-center h-48">
          <div className="animate-spin w-8 h-8 rounded-full border-2 border-sky-500 border-t-transparent" />
        </div>
      ) : filteredRuns.length === 0 ? (
        <div className="text-center py-20 text-slate-500 text-sm">
          <p className="text-4xl mb-3">🧪</p>
          <p className="font-medium text-slate-400">No test runs found</p>
          <p className="mt-1">Upload test results to get started.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-4">
          {filteredRuns.map((run) => (
            <TestRunCard key={run.id} run={run} onDelete={handleDelete} />
          ))}
        </div>
      )}

      {/* Pagination */}
      {pages > 1 && (
        <div className="flex items-center justify-center gap-2 pt-2">
          <button
            onClick={() => setPage((p) => Math.max(1, p - 1))}
            disabled={page === 1}
            className="px-3 py-1.5 rounded-lg border border-slate-600 text-sm text-slate-300 disabled:opacity-40 hover:border-slate-400 transition-colors"
          >
            ← Prev
          </button>
          <span className="text-sm text-slate-400">Page {page} of {pages}</span>
          <button
            onClick={() => setPage((p) => Math.min(pages, p + 1))}
            disabled={page === pages}
            className="px-3 py-1.5 rounded-lg border border-slate-600 text-sm text-slate-300 disabled:opacity-40 hover:border-slate-400 transition-colors"
          >
            Next →
          </button>
        </div>
      )}
    </div>
  );
}
