'use client';

import { useEffect, useState } from 'react';
import { AlertTriangle, TrendingDown, BarChart3 } from 'lucide-react';
import { FailureTrendChart } from '@/components/charts/FailureTrendChart';
import { DurationChart } from '@/components/charts/DurationChart';
import { getTrends, getFlakyTests, getAnalyticsSummary } from '@/lib/api';
import type { TrendPoint, FlakyTest, AnalyticsSummary } from '@/types';

export default function AnalyticsPage() {
  const [trends,   setTrends]   = useState<TrendPoint[]>([]);
  const [flaky,    setFlaky]    = useState<FlakyTest[]>([]);
  const [summary,  setSummary]  = useState<AnalyticsSummary | null>(null);
  const [days,     setDays]     = useState(30);
  const [loading,  setLoading]  = useState(true);

  useEffect(() => {
    setLoading(true);
    Promise.all([getTrends(days), getFlakyTests(), getAnalyticsSummary()])
      .then(([t, f, s]) => { setTrends(t); setFlaky(f); setSummary(s); })
      .catch(console.error)
      .finally(() => setLoading(false));
  }, [days]);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">Analytics</h1>
          <p className="text-slate-400 text-sm mt-1">Trends, failure patterns and flaky tests</p>
        </div>
        <select
          value={days}
          onChange={(e) => setDays(Number(e.target.value))}
          className="px-3 py-2 rounded-lg bg-slate-700/50 border border-slate-600 text-sm text-white focus:outline-none focus:border-sky-500"
        >
          <option value={7}>Last 7 days</option>
          <option value={30}>Last 30 days</option>
          <option value={90}>Last 90 days</option>
        </select>
      </div>

      {loading ? (
        <div className="flex items-center justify-center h-48">
          <div className="animate-spin w-8 h-8 rounded-full border-2 border-sky-500 border-t-transparent" />
        </div>
      ) : (
        <>
          {/* Summary Metrics */}
          {summary && (
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
              {[
                { label: 'Total Runs',    value: summary.total_runs },
                { label: 'Total Tests',   value: summary.total_tests.toLocaleString() },
                { label: 'Pass Rate',     value: `${summary.overall_pass_rate.toFixed(1)}%` },
                { label: 'Avg Duration',  value: `${summary.average_duration.toFixed(1)}s` },
              ].map(({ label, value }) => (
                <div key={label} className="rounded-xl border border-slate-700 bg-slate-800/60 p-4">
                  <p className="text-xs text-slate-400">{label}</p>
                  <p className="text-2xl font-bold text-white mt-1">{value}</p>
                </div>
              ))}
            </div>
          )}

          {/* Charts */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <FailureTrendChart data={trends} />
            <DurationChart     data={trends} />
          </div>

          {/* Flaky Tests */}
          <div className="rounded-xl border border-slate-700 bg-slate-800/60">
            <div className="flex items-center gap-2 px-5 py-4 border-b border-slate-700">
              <AlertTriangle className="w-4 h-4 text-amber-400" />
              <h2 className="font-semibold text-white">Flaky Tests</h2>
              <span className="text-xs text-slate-500 ml-1">Tests with intermittent failures</span>
            </div>

            {flaky.length === 0 ? (
              <div className="px-5 py-10 text-center text-slate-500 text-sm">
                <TrendingDown className="w-8 h-8 mx-auto mb-2 text-emerald-400 opacity-50" />
                No flaky tests detected. 
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-slate-700 text-left">
                      <th className="px-5 py-3 text-xs font-semibold text-slate-400">Test Name</th>
                      <th className="px-5 py-3 text-xs font-semibold text-slate-400 text-right">Failures</th>
                      <th className="px-5 py-3 text-xs font-semibold text-slate-400 text-right">Total Runs</th>
                      <th className="px-5 py-3 text-xs font-semibold text-slate-400 text-right">Failure Rate</th>
                    </tr>
                  </thead>
                  <tbody>
                    {flaky.map((test, i) => (
                      <tr key={i} className="border-b border-slate-700/50 hover:bg-slate-700/20 transition-colors">
                        <td className="px-5 py-3">
                          <p className="text-sm font-medium text-white">{test.name}</p>
                          {test.class_name && <p className="text-xs text-slate-500 mt-0.5">{test.class_name}</p>}
                        </td>
                        <td className="px-5 py-3 text-sm text-red-400 font-semibold text-right">{test.failure_count}</td>
                        <td className="px-5 py-3 text-sm text-slate-400 text-right">{test.total_runs}</td>
                        <td className="px-5 py-3 text-right">
                          <span className={`text-sm font-semibold ${test.failure_rate >= 50 ? 'text-red-400' : 'text-amber-400'}`}>
                            {test.failure_rate}%
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </>
      )}
    </div>
  );
}
