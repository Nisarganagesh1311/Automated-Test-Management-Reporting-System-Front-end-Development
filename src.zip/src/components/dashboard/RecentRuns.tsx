import Link from 'next/link';
import { formatDistanceToNow } from 'date-fns';
import { CheckCircle2, XCircle, Clock, GitBranch } from 'lucide-react';
import { clsx } from 'clsx';
import type { TestRun } from '@/types';

interface RecentRunsProps {
  runs: TestRun[];
}

const statusConfig = {
  passed: { icon: CheckCircle2, color: 'text-emerald-400', bg: 'bg-emerald-500/10' },
  failed: { icon: XCircle,      color: 'text-red-400',     bg: 'bg-red-500/10' },
  error:  { icon: XCircle,      color: 'text-amber-400',   bg: 'bg-amber-500/10' },
};

function passRate(run: TestRun): number {
  return run.total_tests > 0 ? Math.round((run.passed_tests / run.total_tests) * 100) : 0;
}

export function RecentRuns({ runs }: RecentRunsProps) {
  return (
    <div className="rounded-xl border border-slate-700 bg-slate-800/60">
      <div className="flex items-center justify-between px-5 py-4 border-b border-slate-700">
        <h2 className="font-semibold text-white">Recent Test Runs</h2>
        <Link href="/test-runs" className="text-xs text-sky-400 hover:text-sky-300 transition-colors">
          View all →
        </Link>
      </div>
      {runs.length === 0 ? (
        <div className="px-5 py-10 text-center text-slate-500 text-sm">
          No test runs yet. Upload your first results.
        </div>
      ) : (
        <ul className="divide-y divide-slate-700/50">
          {runs.map((run) => {
            const { icon: StatusIcon, color, bg } = statusConfig[run.status] ?? statusConfig.error;
            const rate = passRate(run);
            return (
              <li key={run.id}>
                <Link
                  href={`/test-runs/${run.id}`}
                  className="flex items-center gap-4 px-5 py-3.5 hover:bg-slate-700/30 transition-colors group"
                >
                  <div className={clsx('w-9 h-9 rounded-lg flex items-center justify-center', bg)}>
                    <StatusIcon className={clsx('w-5 h-5', color)} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-white truncate group-hover:text-sky-300 transition-colors">
                      {run.name}
                    </p>
                    <div className="flex items-center gap-3 mt-0.5">
                      {run.branch && (
                        <span className="flex items-center gap-1 text-xs text-slate-500">
                          <GitBranch className="w-3 h-3" /> {run.branch}
                        </span>
                      )}
                      <span className="flex items-center gap-1 text-xs text-slate-500">
                        <Clock className="w-3 h-3" /> {formatDistanceToNow(new Date(run.created_at), { addSuffix: true })}
                      </span>
                    </div>
                  </div>
                  <div className="text-right flex-shrink-0">
                    <p className={clsx('text-sm font-semibold', rate >= 80 ? 'text-emerald-400' : rate >= 50 ? 'text-amber-400' : 'text-red-400')}>
                      {rate}%
                    </p>
                    <p className="text-xs text-slate-500">{run.total_tests} tests</p>
                  </div>
                </Link>
              </li>
            );
          })}
        </ul>
      )}
    </div>
  );
}
