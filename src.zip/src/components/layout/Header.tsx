'use client';

import Link from 'next/link';
import { Upload, Bell } from 'lucide-react';

export function Header() {
  return (
    <header className="h-14 flex items-center justify-between px-6 bg-slate-800 border-b border-slate-700 flex-shrink-0">
      <div />
      <div className="flex items-center gap-3">
        <Link
          href="/upload"
          className="flex items-center gap-2 px-4 py-1.5 rounded-lg bg-sky-500 hover:bg-sky-400 text-white text-sm font-medium transition-colors"
        >
          <Upload className="w-4 h-4" />
          Upload Results
        </Link>
        <button className="w-9 h-9 flex items-center justify-center rounded-lg text-slate-400 hover:text-slate-200 hover:bg-slate-700 transition-colors">
          <Bell className="w-4 h-4" />
        </button>
      </div>
    </header>
  );
}
