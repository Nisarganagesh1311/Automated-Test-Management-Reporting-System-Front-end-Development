'use client';

import { useCallback, useState } from 'react';
import { useDropzone } from 'react-dropzone';
import { Upload, FileText, X, CheckCircle, AlertCircle, Loader2 } from 'lucide-react';
import { clsx } from 'clsx';
import { uploadTestResults } from '@/lib/api';

type SourceType = 'junit' | 'pytest' | 'playwright';

const SOURCE_TYPES: { value: SourceType; label: string; hint: string }[] = [
  { value: 'junit',      label: 'JUnit XML',       hint: '.xml — Maven Surefire, TestNG, Ant' },
  { value: 'pytest',     label: 'PyTest JSON',      hint: '.json — pytest-json-report plugin' },
  { value: 'playwright', label: 'Playwright JSON',  hint: '.json — @playwright/test reporter' },
];

type UploadState = 'idle' | 'uploading' | 'success' | 'error';

export function UploadDropzone() {
  const [file, setFile] = useState<File | null>(null);
  const [sourceType, setSourceType] = useState<SourceType>('junit');
  const [runName, setRunName] = useState('');
  const [project, setProject] = useState('');
  const [branch, setBranch] = useState('');
  const [commitHash, setCommitHash] = useState('');
  const [notifySlack, setNotifySlack] = useState(false);
  const [notifyTeams, setNotifyTeams] = useState(false);
  const [state, setState] = useState<UploadState>('idle');
  const [errorMsg, setErrorMsg] = useState('');
  const [resultId, setResultId] = useState('');

  const onDrop = useCallback((accepted: File[]) => {
    if (accepted[0]) setFile(accepted[0]);
  }, []);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: { 'text/xml': ['.xml'], 'application/xml': ['.xml'], 'application/json': ['.json'] },
    maxFiles: 1,
    maxSize: 20 * 1024 * 1024,
  });

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!file) return;

    setState('uploading');
    setErrorMsg('');

    const fd = new FormData();
    fd.append('file', file);
    fd.append('source_type', sourceType);
    if (runName) fd.append('name', runName);
    if (project)  fd.append('project', project);
    if (branch)   fd.append('branch', branch);
    if (commitHash) fd.append('commit_hash', commitHash);
    fd.append('notify_slack', notifySlack ? 'true' : 'false');
    fd.append('notify_teams', notifyTeams ? 'true' : 'false');

    try {
      const result = await uploadTestResults(fd);
      setResultId(result.id);
      setState('success');
    } catch (err: any) {
      setErrorMsg(err?.response?.data?.detail || 'Upload failed. Please try again.');
      setState('error');
    }
  }

  function reset() {
    setFile(null);
    setRunName('');
    setState('idle');
    setErrorMsg('');
    setResultId('');
  }

  if (state === 'success') {
    return (
      <div className="rounded-xl border border-emerald-500/30 bg-emerald-500/10 p-10 text-center">
        <CheckCircle className="w-12 h-12 text-emerald-400 mx-auto mb-4" />
        <h3 className="text-xl font-semibold text-white mb-2">Upload Successful!</h3>
        <p className="text-slate-400 text-sm mb-6">Your test results have been processed and are ready to view.</p>
        <div className="flex items-center justify-center gap-3">
          <a
            href={`/test-runs/${resultId}`}
            className="px-5 py-2 rounded-lg bg-sky-500 hover:bg-sky-400 text-white text-sm font-medium transition-colors"
          >
            View Results
          </a>
          <button
            onClick={reset}
            className="px-5 py-2 rounded-lg border border-slate-600 text-slate-300 hover:border-slate-500 text-sm font-medium transition-colors"
          >
            Upload Another
          </button>
        </div>
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      {/* Source Type */}
      <div>
        <label className="block text-sm font-medium text-slate-300 mb-3">Test Framework</label>
        <div className="grid grid-cols-3 gap-3">
          {SOURCE_TYPES.map(({ value, label, hint }) => (
            <button
              key={value}
              type="button"
              onClick={() => setSourceType(value)}
              className={clsx(
                'px-4 py-3 rounded-lg border text-left transition-all',
                sourceType === value
                  ? 'border-sky-500 bg-sky-500/10 ring-1 ring-sky-500'
                  : 'border-slate-600 hover:border-slate-500',
              )}
            >
              <p className="text-sm font-medium text-white">{label}</p>
              <p className="text-xs text-slate-500 mt-0.5">{hint}</p>
            </button>
          ))}
        </div>
      </div>

      {/* Dropzone */}
      <div>
        <label className="block text-sm font-medium text-slate-300 mb-2">Test Result File</label>
        <div
          {...getRootProps()}
          className={clsx(
            'border-2 border-dashed rounded-xl p-8 text-center cursor-pointer transition-all',
            isDragActive  ? 'border-sky-400 bg-sky-500/10' : 'border-slate-600 hover:border-slate-400 hover:bg-slate-700/20',
            file          ? 'border-emerald-500/50 bg-emerald-500/5' : '',
          )}
        >
          <input {...getInputProps()} />
          {file ? (
            <div className="flex items-center justify-center gap-3">
              <FileText className="w-6 h-6 text-emerald-400" />
              <div className="text-left">
                <p className="text-sm font-medium text-white">{file.name}</p>
                <p className="text-xs text-slate-400">{(file.size / 1024).toFixed(1)} KB</p>
              </div>
              <button
                type="button"
                onClick={(e) => { e.stopPropagation(); setFile(null); }}
                className="ml-4 text-slate-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          ) : (
            <>
              <Upload className="w-8 h-8 text-slate-400 mx-auto mb-2" />
              <p className="text-sm text-slate-300">{isDragActive ? 'Drop the file here' : 'Drag & drop your test result file'}</p>
              <p className="text-xs text-slate-500 mt-1">or click to browse — XML / JSON, max 20MB</p>
            </>
          )}
        </div>
      </div>

      {/* Metadata */}
      <div className="grid grid-cols-2 gap-4">
        {[
          { label: 'Run Name', value: runName, set: setRunName, placeholder: 'e.g. Nightly Build #234' },
          { label: 'Project',  value: project, set: setProject, placeholder: 'e.g. checkout-service' },
          { label: 'Branch',   value: branch,  set: setBranch,  placeholder: 'e.g. main' },
          { label: 'Commit SHA', value: commitHash, set: setCommitHash, placeholder: '7-char hash' },
        ].map(({ label, value, set, placeholder }) => (
          <div key={label}>
            <label className="block text-xs font-medium text-slate-400 mb-1">{label}</label>
            <input
              type="text"
              value={value}
              onChange={(e) => set(e.target.value)}
              placeholder={placeholder}
              className="w-full px-3 py-2 rounded-lg bg-slate-700/50 border border-slate-600 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-sky-500 transition-colors"
            />
          </div>
        ))}
      </div>

      {/* Notifications */}
      <div>
        <label className="block text-sm font-medium text-slate-300 mb-3">Notifications</label>
        <div className="flex gap-6">
          {[
            { label: 'Slack', checked: notifySlack, set: setNotifySlack },
            { label: 'Teams', checked: notifyTeams, set: setNotifyTeams },
          ].map(({ label, checked, set }) => (
            <label key={label} className="flex items-center gap-2 cursor-pointer">
              <input
                type="checkbox"
                checked={checked}
                onChange={(e) => set(e.target.checked)}
                className="w-4 h-4 accent-sky-500"
              />
              <span className="text-sm text-slate-300">{label}</span>
            </label>
          ))}
        </div>
      </div>

      {state === 'error' && (
        <div className="flex items-center gap-2 px-4 py-3 rounded-lg bg-red-500/10 border border-red-500/30 text-red-400 text-sm">
          <AlertCircle className="w-4 h-4 flex-shrink-0" />
          {errorMsg}
        </div>
      )}

      <button
        type="submit"
        disabled={!file || state === 'uploading'}
        className={clsx(
          'w-full py-3 rounded-xl font-semibold text-white transition-all',
          file && state !== 'uploading'
            ? 'bg-sky-500 hover:bg-sky-400 cursor-pointer'
            : 'bg-slate-700 cursor-not-allowed text-slate-400',
        )}
      >
        {state === 'uploading' ? (
          <span className="flex items-center justify-center gap-2">
            <Loader2 className="w-4 h-4 animate-spin" /> Processing…
          </span>
        ) : 'Upload & Analyze'}
      </button>
    </form>
  );
}
