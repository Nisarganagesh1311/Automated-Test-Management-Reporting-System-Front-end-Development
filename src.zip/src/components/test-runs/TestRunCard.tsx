import Link from 'next/link';
import { formatDistanceToNow } from 'date-fns';
import { CheckCircle2, XCircle, Clock, GitBranch, GitCommit, Trash2 } from 'lucide-react';
import { clsx } from 'clsx';
import type { TestRun } from '@/types';

interface TestRunCardProps {
  run: TestRun;
  onDelete: (id: string) => void;
}

const sourceLabel: Record<string, string> = {
  junit: 'JUnit',
  pytest: 'PyTest',
  playwright: 'Playwright',
};

function ProgressBar({ passed, failed, skipped, total }: { passed: number; failed: number; skipped: number; total: number }) {
  if (total === 0) return null;
  return (
    <div className="flex h-1.5 rounded-full overflow-hidden gap-px mt-3">
      <div className="bg-emerald-500" style={{ width: `${(passed / total) * 100}%` }} />
      <div className="bg-red-500"     style={{ width: `${(failed / total) * 100}%` }} />
      <div className="bg-amber-400"   style={{ width: `${(skipped / total) * 100}%` }} />
    </div>
  );
}

export function TestRunCard({ run, onDelete }: TestRunCardProps) {
  const isOk  = run.status === 'passed';
  const rate  = run.total_tests > 0 ? Math.round((run.passed_tests / run.total_tests) * 100) : 0;

  return (
    <div className="rounded-xl border border-slate-700 bg-slate-800/60 p-5 hover:border-slate-600 transition-colors group">
      <div className="flex items-start justify-between gap-3">
        <div className="flex items-center gap-3 min-w-0">
          {isOk
            ? <CheckCircle2 className="w-5 h-5 text-emerald-400 flex-shrink-0" />
            : <XCircle     className="w-5 h-5 text-red-400 flex-shrink-0" />
          }
          <div className="min-w-0">
            <Link href={`/test-runs/${run.id}`} className="text-sm font-semibold text-white hover:text-sky-400 transition-colors block truncate">
              {run.name}
            </Link>
            <div className="flex items-center gap-3 mt-1 flex-wrap">
              <span className={clsx(
                'text-xs px-1.5 py-0.5 rounded font-medium',
                sourceLabel[run.source_type] === 'JUnit'      ? 'bg-orange-500/20 text-orange-400' :
                sourceLabel[run.source_type] === 'PyTest'     ? 'bg-green-500/20 text-green-400'   :
                                                                'bg-purple-500/20 text-purple-400',
              )}>
                {sourceLabel[run.source_type] || run.source_type}
              </span>
              {run.project && <span className="text-xs text-slate-500">{run.project}</span>}
              {run.branch && (
                <span className="flex items-center gap-1 text-xs text-slate-500">
                  <GitBranch className="w-3 h-3" /> {run.branch}
                </span>
              )}
              {run.commit_hash && (
                <span className="flex items-center gap-1 text-xs text-slate-500">
                  <GitCommit className="w-3 h-3" /> {run.commit_hash.slice(0, 7)}
                </span>
              )}
            </div>
          </div>
        </div>
        <div className="flex items-center gap-2 flex-shrink-0">
          <div className="text-right">
            <p className={clsx('text-lg font-bold', rate >= 80 ? 'text-emerald-400' : rate >= 50 ? 'text-amber-400' : 'text-red-400')}>
              {rate}%
            </p>
            <p className="text-xs text-slate-500">{run.total_tests} tests</p>
          </div>
          <button
            onClick={() => onDelete(run.id)}
            className="ml-1 p-1.5 rounded-lg text-slate-500 hover:text-red-400 hover:bg-red-500/10 transition-colors opacity-0 group-hover:opacity-100"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      </div>

      <ProgressBar passed={run.passed_tests} failed={run.failed_tests} skipped={run.skipped_tests} total={run.total_tests} />

      <div className="flex items-center justify-between mt-3">
        <div className="flex items-center gap-4 text-xs">
          <span className="text-emerald-400">{run.passed_tests} passed</span>
          {run.failed_tests > 0   && <span className="text-red-400">{run.failed_tests} failed</span>}
          {run.skipped_tests > 0  && <span className="text-amber-400">{run.skipped_tests} skipped</span>}
        </div>
        <div className="flex items-center gap-1 text-xs text-slate-500">
          <Clock className="w-3 h-3" />
          {formatDistanceToNow(new Date(run.created_at), { addSuffix: true })}
        </div>
      </div>
    </div>
  );
}
