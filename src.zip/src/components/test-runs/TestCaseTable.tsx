'use client';

import { useState } from 'react';
import { CheckCircle2, XCircle, SkipForward, AlertTriangle, ChevronDown, ChevronRight } from 'lucide-react';
import { clsx } from 'clsx';
import type { TestCase } from '@/types';

interface TestCaseTableProps {
  cases: TestCase[];
}

const STATUS_CONFIG = {
  passed:  { icon: CheckCircle2,  color: 'text-emerald-400', bg: 'bg-emerald-500/10', label: 'Passed'  },
  failed:  { icon: XCircle,       color: 'text-red-400',     bg: 'bg-red-500/10',     label: 'Failed'  },
  skipped: { icon: SkipForward,   color: 'text-amber-400',   bg: 'bg-amber-500/10',   label: 'Skipped' },
  error:   { icon: AlertTriangle, color: 'text-orange-400',  bg: 'bg-orange-500/10',  label: 'Error'   },
};

function TestCaseRow({ tc }: { tc: TestCase }) {
  const [expanded, setExpanded] = useState(false);
  const cfg = STATUS_CONFIG[tc.status] ?? STATUS_CONFIG.error;
  const StatusIcon = cfg.icon;
  const hasDetail = tc.error_message || tc.stack_trace;

  return (
    <>
      <tr
        className={clsx('border-b border-slate-700/50 hover:bg-slate-700/20 transition-colors', hasDetail && 'cursor-pointer')}
        onClick={() => hasDetail && setExpanded(!expanded)}
      >
        <td className="px-4 py-3">
          <div className="flex items-center gap-2">
            {hasDetail ? (
              expanded ? <ChevronDown className="w-3.5 h-3.5 text-slate-400" /> : <ChevronRight className="w-3.5 h-3.5 text-slate-400" />
            ) : <span className="w-3.5" />}
            <div className={clsx('w-6 h-6 rounded flex items-center justify-center flex-shrink-0', cfg.bg)}>
              <StatusIcon className={clsx('w-3.5 h-3.5', cfg.color)} />
            </div>
            <div className="min-w-0">
              <p className="text-sm text-white font-medium truncate max-w-xs">{tc.name}</p>
              {tc.class_name && <p className="text-xs text-slate-500 truncate">{tc.class_name}</p>}
            </div>
          </div>
        </td>
        <td className="px-4 py-3">
          <span className={clsx('text-xs font-medium px-2 py-0.5 rounded', cfg.bg, cfg.color)}>{cfg.label}</span>
        </td>
        <td className="px-4 py-3 text-xs text-slate-400 text-right">{tc.duration.toFixed(3)}s</td>
        <td className="px-4 py-3 text-xs text-slate-500 truncate max-w-[200px]">
          {tc.error_message?.slice(0, 60) ?? '—'}
        </td>
      </tr>
      {expanded && hasDetail && (
        <tr className="bg-slate-900/50">
          <td colSpan={4} className="px-8 py-4">
            {tc.error_message && (
              <div className="mb-3">
                <p className="text-xs font-semibold text-red-400 mb-1">Error Message</p>
                <p className="text-sm text-slate-300 font-mono">{tc.error_message}</p>
              </div>
            )}
            {tc.stack_trace && (
              <div>
                <p className="text-xs font-semibold text-slate-400 mb-1">Stack Trace</p>
                <pre className="text-xs text-slate-400 font-mono bg-slate-800 rounded-lg p-3 overflow-x-auto whitespace-pre-wrap max-h-48">
                  {tc.stack_trace}
                </pre>
              </div>
            )}
          </td>
        </tr>
      )}
    </>
  );
}

const STATUS_TABS = ['all', 'failed', 'passed', 'skipped', 'error'] as const;

export function TestCaseTable({ cases }: TestCaseTableProps) {
  const [filter, setFilter] = useState<string>('all');

  const filtered = filter === 'all' ? cases : cases.filter((c) => c.status === filter);
  const counts = cases.reduce((acc, c) => { acc[c.status] = (acc[c.status] || 0) + 1; return acc; }, {} as Record<string, number>);

  return (
    <div className="rounded-xl border border-slate-700 bg-slate-800/60 overflow-hidden">
      {/* Filter Tabs */}
      <div className="flex items-center gap-1 px-4 py-3 border-b border-slate-700 overflow-x-auto">
        {STATUS_TABS.map((tab) => (
          <button
            key={tab}
            onClick={() => setFilter(tab)}
            className={clsx(
              'px-3 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap capitalize transition-colors',
              filter === tab
                ? 'bg-sky-500/20 text-sky-400'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-700',
            )}
          >
            {tab} {tab !== 'all' && counts[tab] != null ? `(${counts[tab]})` : tab === 'all' ? `(${cases.length})` : ''}
          </button>
        ))}
      </div>

      <div className="overflow-x-auto">
        <table className="w-full">
          <thead>
            <tr className="border-b border-slate-700 text-left">
              <th className="px-4 py-3 text-xs font-semibold text-slate-400 w-1/2">Test Name</th>
              <th className="px-4 py-3 text-xs font-semibold text-slate-400 w-24">Status</th>
              <th className="px-4 py-3 text-xs font-semibold text-slate-400 text-right w-24">Duration</th>
              <th className="px-4 py-3 text-xs font-semibold text-slate-400">Message</th>
            </tr>
          </thead>
          <tbody>
            {filtered.length === 0 ? (
              <tr>
                <td colSpan={4} className="px-4 py-10 text-center text-slate-500 text-sm">
                  No tests match this filter.
                </td>
              </tr>
            ) : (
              filtered.map((tc) => <TestCaseRow key={tc.id} tc={tc} />)
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
