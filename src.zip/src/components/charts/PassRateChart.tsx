'use client';

import {
  PieChart,
  Pie,
  Cell,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from 'recharts';
import type { AnalyticsSummary } from '@/types';

interface PassRateChartProps {
  summary: AnalyticsSummary;
}

const COLOR_MAP: Record<string, string> = {
  Passed: '#10b981',
  Failed: '#ef4444',
  Skipped: '#f59e0b',
};

const CustomTooltip = ({ active, payload }: any) => {
  if (!active || !payload?.length) return null;
  const { name, value } = payload[0];
  return (
    <div className="bg-slate-800 border border-slate-600 rounded-lg px-4 py-2 shadow-xl text-sm">
      <span className="text-slate-300">{name}: </span>
      <span className="font-semibold text-white">{value}</span>
    </div>
  );
};

export function PassRateChart({ summary }: PassRateChartProps) {
  const failed = 100 - summary.overall_pass_rate;

  const chartData = [
    { name: 'Passed', value: Math.round(summary.overall_pass_rate) },
    { name: 'Failed', value: Math.round(failed) },
  ].filter((d) => d.value > 0);

  return (
    <div className="rounded-xl border border-slate-700 bg-slate-800/60 p-5">
      <h2 className="font-semibold text-white mb-1">Overall Pass Rate</h2>
      <p className="text-4xl font-bold text-white mb-4">
        {summary.overall_pass_rate.toFixed(1)}
        <span className="text-xl text-slate-400">%</span>
      </p>
      <ResponsiveContainer width="100%" height={180}>
        <PieChart>
          <Pie
            data={chartData}
            cx="50%"
            cy="50%"
            innerRadius={55}
            outerRadius={80}
            paddingAngle={3}
            dataKey="value"
          >
            {chartData.map((entry) => (
              <Cell key={entry.name} fill={COLOR_MAP[entry.name] ?? '#6366f1'} />
            ))}
          </Pie>
          <Tooltip content={<CustomTooltip />} />
          <Legend
            formatter={(value) => <span style={{ color: '#94a3b8', fontSize: '12px' }}>{value}</span>}
          />
        </PieChart>
      </ResponsiveContainer>
    </div>
  );
}
