'use client';

import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from 'recharts';
import type { TrendPoint } from '@/types';
import { format, parseISO } from 'date-fns';

interface DurationChartProps {
  data: TrendPoint[];
}

export function DurationChart({ data }: DurationChartProps) {
  const formatted = data.map((d) => ({
    date: (() => { try { return format(parseISO(d.date), 'MMM d'); } catch { return d.date; } })(),
    total: d.total,
  }));

  return (
    <div className="rounded-xl border border-slate-700 bg-slate-800/60 p-5">
      <h2 className="font-semibold text-white mb-4">Total Tests Per Day</h2>
      <ResponsiveContainer width="100%" height={220}>
        <BarChart data={formatted} margin={{ top: 5, right: 10, left: -20, bottom: 0 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
          <XAxis dataKey="date" tick={{ fill: '#94a3b8', fontSize: 11 }} axisLine={false} tickLine={false} />
          <YAxis tick={{ fill: '#94a3b8', fontSize: 11 }} axisLine={false} tickLine={false} />
          <Tooltip
            contentStyle={{ background: '#1e293b', border: '1px solid #475569', borderRadius: '8px' }}
            labelStyle={{ color: '#94a3b8' }}
            itemStyle={{ color: '#f1f5f9' }}
          />
          <Bar dataKey="total" fill="#0ea5e9" radius={[4, 4, 0, 0]} name="Tests" />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}
