import axios from 'axios';
import type {
  PaginatedTestRuns,
  TestRunDetail,
  TestCase,
  AnalyticsSummary,
  TrendPoint,
  FlakyTest,
} from '@/types';

const api = axios.create({
  baseURL: process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000',
});

// ── Test Runs ─────────────────────────────────────────────────────────────────

export async function getTestRuns(
  page = 1,
  pageSize = 20,
  project?: string,
  status?: string,
): Promise<PaginatedTestRuns> {
  const params: Record<string, string | number> = { page, page_size: pageSize };
  if (project) params.project = project;
  if (status) params.status = status;
  const { data } = await api.get('/api/test-runs', { params });
  return data;
}

export async function getTestRun(id: string): Promise<TestRunDetail> {
  const { data } = await api.get(`/api/test-runs/${id}`);
  return data;
}

export async function getTestCases(runId: string, status?: string): Promise<TestCase[]> {
  const params: Record<string, string> = {};
  if (status) params.status = status;
  const { data } = await api.get(`/api/test-runs/${runId}/cases`, { params });
  return data;
}

export async function deleteTestRun(id: string): Promise<void> {
  await api.delete(`/api/test-runs/${id}`);
}

// ── Upload ────────────────────────────────────────────────────────────────────

export async function uploadTestResults(formData: FormData) {
  const { data } = await api.post('/api/upload', formData, {
    headers: { 'Content-Type': 'multipart/form-data' },
  });
  return data;
}

// ── Analytics ─────────────────────────────────────────────────────────────────

export async function getAnalyticsSummary(): Promise<AnalyticsSummary> {
  const { data } = await api.get('/api/analytics/summary');
  return data;
}

export async function getTrends(days = 30, project?: string): Promise<TrendPoint[]> {
  const params: Record<string, string | number> = { days };
  if (project) params.project = project;
  const { data } = await api.get('/api/analytics/trends', { params });
  return data;
}

export async function getFlakyTests(minRuns = 3): Promise<FlakyTest[]> {
  const { data } = await api.get('/api/analytics/flaky', { params: { min_runs: minRuns } });
  return data;
}

export async function getProjects(): Promise<string[]> {
  const { data } = await api.get('/api/analytics/projects');
  return data;
}

// ── Notifications ─────────────────────────────────────────────────────────────

export async function testNotification(type: 'slack' | 'teams', webhookUrl: string) {
  const { data } = await api.post('/api/notifications/test', { type, webhook_url: webhookUrl });
  return data;
}
