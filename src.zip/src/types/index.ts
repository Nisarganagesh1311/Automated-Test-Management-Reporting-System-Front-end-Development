export interface TestRun {
  id: string;
  name: string;
  project?: string;
  branch?: string;
  commit_hash?: string;
  source_type: 'junit' | 'pytest' | 'playwright';
  status: 'passed' | 'failed' | 'error';
  total_tests: number;
  passed_tests: number;
  failed_tests: number;
  skipped_tests: number;
  error_tests: number;
  duration: number;
  ai_summary?: string;
  created_at: string;
  updated_at: string;
}

export interface TestCase {
  id: string;
  name: string;
  class_name?: string;
  file_path?: string;
  status: 'passed' | 'failed' | 'skipped' | 'error';
  duration: number;
  error_message?: string;
  error_type?: string;
  stack_trace?: string;
}

export interface TestRunDetail extends TestRun {
  test_cases: TestCase[];
}

export interface PaginatedTestRuns {
  items: TestRun[];
  total: number;
  page: number;
  page_size: number;
  total_pages: number;
}

export interface AnalyticsSummary {
  total_runs: number;
  total_tests: number;
  overall_pass_rate: number;
  average_duration: number;
  failed_runs_today: number;
}

export interface TrendPoint {
  date: string;
  passed: number;
  failed: number;
  skipped: number;
  total: number;
}

export interface FlakyTest {
  name: string;
  class_name?: string;
  failure_count: number;
  total_runs: number;
  failure_rate: number;
}
