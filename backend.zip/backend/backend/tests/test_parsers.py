"""Basic unit tests for parsers."""
import pytest
from app.services.parsers import parse_junit, parse_pytest, parse_playwright
from app.schemas import TestCaseStatusEnum


JUNIT_XML = b"""<?xml version="1.0"?>
<testsuites>
  <testsuite name="Suite1" time="1.5">
    <testcase name="test_pass" classname="MyTest" time="0.5"/>
    <testcase name="test_fail" classname="MyTest" time="0.4">
      <failure type="AssertionError" message="wrong value">stacktrace here</failure>
    </testcase>
    <testcase name="test_skip" classname="MyTest" time="0.0">
      <skipped/>
    </testcase>
  </testsuite>
</testsuites>"""


PYTEST_JSON = b"""{
  "duration": 2.1,
  "tests": [
    {"nodeid": "tests/test_foo.py::test_ok",   "outcome": "passed", "duration": 0.5},
    {"nodeid": "tests/test_foo.py::test_bad",  "outcome": "failed", "duration": 0.3,
     "call": {"longrepr": "AssertionError: boom"}}
  ]
}"""


PLAYWRIGHT_JSON = b"""{
  "suites": [{
    "title": "Home",
    "file": "tests/home.spec.ts",
    "suites": [{
      "title": "Nav",
      "tests": [
        {"title": "loads", "status": "passed", "results": [{"status": "passed", "duration": 800}]},
        {"title": "404",   "status": "failed",  "results": [{"status": "failed",  "duration": 2000,
          "errors": [{"message": "Expected 404", "stack": "at line 10"}]}]}
      ]
    }]
  }]
}"""


class TestJUnitParser:
    def test_passes_count(self):
        cases, dur = parse_junit(JUNIT_XML)
        assert len(cases) == 3
        assert sum(1 for c in cases if c.status == TestCaseStatusEnum.passed) == 1
        assert sum(1 for c in cases if c.status == TestCaseStatusEnum.failed) == 1
        assert sum(1 for c in cases if c.status == TestCaseStatusEnum.skipped) == 1

    def test_duration(self):
        _, dur = parse_junit(JUNIT_XML)
        assert dur == pytest.approx(1.5)

    def test_error_details(self):
        cases, _ = parse_junit(JUNIT_XML)
        failed = next(c for c in cases if c.status == TestCaseStatusEnum.failed)
        assert failed.error_type == "AssertionError"
        assert "wrong value" in (failed.error_message or "")


class TestPyTestParser:
    def test_counts(self):
        cases, dur = parse_pytest(PYTEST_JSON)
        assert len(cases) == 2
        assert dur == pytest.approx(2.1)

    def test_file_path_extracted(self):
        cases, _ = parse_pytest(PYTEST_JSON)
        assert cases[0].file_path == "tests/test_foo.py"
        assert cases[0].name == "test_ok"


class TestPlaywrightParser:
    def test_counts(self):
        cases, dur = parse_playwright(PLAYWRIGHT_JSON)
        assert len(cases) == 2

    def test_failed_has_error(self):
        cases, _ = parse_playwright(PLAYWRIGHT_JSON)
        failed = next(c for c in cases if c.status == TestCaseStatusEnum.failed)
        assert "Expected 404" in (failed.error_message or "")
