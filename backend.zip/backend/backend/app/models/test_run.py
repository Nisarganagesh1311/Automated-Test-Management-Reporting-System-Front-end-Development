import uuid
from datetime import datetime
from sqlalchemy import Column, String, Integer, Float, DateTime, Text, Enum as SAEnum
from sqlalchemy.orm import relationship
from app.database import Base
import enum


class TestRunStatus(str, enum.Enum):
    passed = "passed"
    failed = "failed"
    error = "error"


class TestSourceType(str, enum.Enum):
    junit = "junit"
    pytest = "pytest"
    playwright = "playwright"


class TestRun(Base):
    __tablename__ = "test_runs"

    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    name = Column(String(255), nullable=False)
    project = Column(String(255), nullable=True)
    branch = Column(String(255), nullable=True)
    commit_hash = Column(String(64), nullable=True)

    source_type = Column(SAEnum(TestSourceType), nullable=False, default=TestSourceType.junit)
    status = Column(SAEnum(TestRunStatus), nullable=False, default=TestRunStatus.passed)

    total_tests = Column(Integer, default=0)
    passed_tests = Column(Integer, default=0)
    failed_tests = Column(Integer, default=0)
    skipped_tests = Column(Integer, default=0)
    error_tests = Column(Integer, default=0)
    duration = Column(Float, default=0.0)

    ai_summary = Column(Text, nullable=True)

    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    test_cases = relationship("TestCase", back_populates="test_run", cascade="all, delete-orphan")
