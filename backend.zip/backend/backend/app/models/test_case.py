import uuid
from sqlalchemy import Column, String, Float, Text, ForeignKey, Enum as SAEnum
from sqlalchemy.orm import relationship
from app.database import Base
import enum


class TestCaseStatus(str, enum.Enum):
    passed = "passed"
    failed = "failed"
    skipped = "skipped"
    error = "error"


class TestCase(Base):
    __tablename__ = "test_cases"

    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    test_run_id = Column(String(36), ForeignKey("test_runs.id"), nullable=False)

    name = Column(String(512), nullable=False)
    class_name = Column(String(512), nullable=True)
    file_path = Column(String(512), nullable=True)

    status = Column(SAEnum(TestCaseStatus), nullable=False, default=TestCaseStatus.passed)
    duration = Column(Float, default=0.0)

    error_message = Column(Text, nullable=True)
    error_type = Column(String(255), nullable=True)
    stack_trace = Column(Text, nullable=True)

    test_run = relationship("TestRun", back_populates="test_cases")
