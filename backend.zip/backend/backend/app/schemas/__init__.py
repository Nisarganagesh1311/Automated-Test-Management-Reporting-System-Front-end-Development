from pydantic import BaseModel, Field
from typing import Optional, List
from datetime import datetime
from enum import Enum


class TestCaseStatusEnum(str, Enum):
    passed = "passed"
    failed = "failed"
    skipped = "skipped"
    error = "error"


class TestRunStatusEnum(str, Enum):
    passed = "passed"
    failed = "failed"
    error = "error"


class TestSourceTypeEnum(str, Enum):
    junit = "junit"
    pytest = "pytest"
    playwright = "playwright"


# ── Test Case Schemas ─────────────────────────────────────────────────────────

class TestCaseBase(BaseModel):
    name: str
    class_name: Optional[str] = None
    file_path: Optional[str] = None
    status: TestCaseStatusEnum
    duration: float = 0.0
    error_message: Optional[str] = None
    error_type: Optional[str] = None
    stack_trace: Optional[str] = None


class TestCaseCreate(TestCaseBase):
    pass


class TestCaseRead(TestCaseBase):
    id: str

    class Config:
        from_attributes = True


# ── Test Run Schemas ──────────────────────────────────────────────────────────

class TestRunCreate(BaseModel):
    name: str
    project: Optional[str] = None
    branch: Optional[str] = None
    commit_hash: Optional[str] = None
    source_type: TestSourceTypeEnum = TestSourceTypeEnum.junit


class TestRunRead(BaseModel):
    id: str
    name: str
    project: Optional[str] = None
    branch: Optional[str] = None
    commit_hash: Optional[str] = None
    source_type: TestSourceTypeEnum
    status: TestRunStatusEnum
    total_tests: int
    passed_tests: int
    failed_tests: int
    skipped_tests: int
    error_tests: int
    duration: float
    ai_summary: Optional[str] = None
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True


class TestRunDetail(TestRunRead):
    test_cases: List[TestCaseRead] = []

    class Config:
        from_attributes = True


# ── Analytics Schemas ─────────────────────────────────────────────────────────

class AnalyticsSummary(BaseModel):
    total_runs: int
    total_tests: int
    overall_pass_rate: float
    average_duration: float
    failed_runs_today: int


class TrendPoint(BaseModel):
    date: str
    passed: int
    failed: int
    skipped: int
    total: int


class FlakyTest(BaseModel):
    name: str
    class_name: Optional[str]
    failure_count: int
    total_runs: int
    failure_rate: float


# ── Notification Schemas ──────────────────────────────────────────────────────

class NotificationTestRequest(BaseModel):
    type: str = Field(..., pattern="^(slack|teams)$")
    webhook_url: str
