"""AI-powered failure summary using OpenAI GPT."""
from typing import List, Optional
from app.schemas import TestCaseRead
from app.config import settings


async def generate_failure_summary(test_run_name: str, failed_cases: List[TestCaseRead]) -> Optional[str]:
    """Generate an AI summary for failed tests. Returns None if OpenAI key not configured."""
    if not settings.OPENAI_API_KEY or settings.OPENAI_API_KEY == "your_openai_api_key_here":
        return _generate_rule_based_summary(test_run_name, failed_cases)

    try:
        from openai import AsyncOpenAI
        client = AsyncOpenAI(api_key=settings.OPENAI_API_KEY)

        failures_text = "\n".join(
            f"- [{tc.status.upper()}] {tc.class_name or ''}.{tc.name}: {tc.error_message or 'No message'}"
            for tc in failed_cases[:20]  # Limit to 20 failures for token efficiency
        )

        prompt = (
            f"Analyze these test failures from test run '{test_run_name}' and provide a concise summary:\n\n"
            f"{failures_text}\n\n"
            "Provide:\n"
            "1. Root cause hypothesis (1-2 sentences)\n"
            "2. Affected components or modules\n"
            "3. Recommended next steps\n"
            "Keep it under 150 words."
        )

        response = await client.chat.completions.create(
            model="gpt-3.5-turbo",
            messages=[{"role": "user", "content": prompt}],
            max_tokens=250,
            temperature=0.3,
        )
        return response.choices[0].message.content.strip()

    except Exception:
        return _generate_rule_based_summary(test_run_name, failed_cases)


def _generate_rule_based_summary(test_run_name: str, failed_cases: List[TestCaseRead]) -> str:
    """Fallback rule-based summary when OpenAI is not available."""
    if not failed_cases:
        return "All tests passed successfully. No failures detected."

    total = len(failed_cases)
    error_types: dict = {}
    affected_classes: set = set()

    for tc in failed_cases:
        if tc.error_type:
            error_types[tc.error_type] = error_types.get(tc.error_type, 0) + 1
        if tc.class_name:
            affected_classes.add(tc.class_name.split(".")[-1])

    top_error = max(error_types, key=error_types.get) if error_types else "Unknown"
    classes_str = ", ".join(list(affected_classes)[:3]) if affected_classes else "multiple modules"

    return (
        f"{total} test(s) failed in '{test_run_name}'. "
        f"Most common failure type: {top_error}. "
        f"Affected areas: {classes_str}. "
        "Review stack traces for detailed root cause analysis. "
        "Consider checking recent code changes in the affected modules."
    )
