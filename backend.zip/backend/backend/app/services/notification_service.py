"""Slack and Microsoft Teams webhook notification service."""
import httpx
from typing import Optional
from app.config import settings


async def send_slack_notification(
    test_run_name: str,
    total: int,
    passed: int,
    failed: int,
    skipped: int,
    run_id: str,
    webhook_url: Optional[str] = None,
) -> bool:
    url = webhook_url or settings.SLACK_WEBHOOK_URL
    if not url:
        return False

    status_emoji = "✅" if failed == 0 else "❌"
    pass_rate = round((passed / total * 100) if total > 0 else 0, 1)

    payload = {
        "blocks": [
            {
                "type": "header",
                "text": {"type": "plain_text", "text": f"{status_emoji} Test Run Complete: {test_run_name}"},
            },
            {
                "type": "section",
                "fields": [
                    {"type": "mrkdwn", "text": f"*Total Tests:*\n{total}"},
                    {"type": "mrkdwn", "text": f"*Pass Rate:*\n{pass_rate}%"},
                    {"type": "mrkdwn", "text": f"*Passed:*\n:white_check_mark: {passed}"},
                    {"type": "mrkdwn", "text": f"*Failed:*\n:x: {failed}"},
                    {"type": "mrkdwn", "text": f"*Skipped:*\n:fast_forward: {skipped}"},
                ],
            },
            {
                "type": "context",
                "elements": [{"type": "mrkdwn", "text": f"Run ID: `{run_id}`"}],
            },
        ]
    }

    try:
        async with httpx.AsyncClient(timeout=10) as client:
            response = await client.post(url, json=payload)
            return response.status_code == 200
    except Exception:
        return False


async def send_teams_notification(
    test_run_name: str,
    total: int,
    passed: int,
    failed: int,
    skipped: int,
    run_id: str,
    webhook_url: Optional[str] = None,
) -> bool:
    url = webhook_url or settings.TEAMS_WEBHOOK_URL
    if not url:
        return False

    status_color = "Good" if failed == 0 else "Attention"
    pass_rate = round((passed / total * 100) if total > 0 else 0, 1)

    payload = {
        "@type": "MessageCard",
        "@context": "http://schema.org/extensions",
        "themeColor": "00C853" if failed == 0 else "FF5252",
        "summary": f"Test Run: {test_run_name}",
        "sections": [
            {
                "activityTitle": f"Test Run Complete: **{test_run_name}**",
                "activitySubtitle": f"Pass Rate: {pass_rate}%",
                "activityImage": "",
                "facts": [
                    {"name": "Total Tests", "value": str(total)},
                    {"name": "Passed", "value": str(passed)},
                    {"name": "Failed", "value": str(failed)},
                    {"name": "Skipped", "value": str(skipped)},
                    {"name": "Run ID", "value": run_id},
                ],
                "markdown": True,
            }
        ],
    }

    try:
        async with httpx.AsyncClient(timeout=10) as client:
            response = await client.post(url, json=payload)
            return response.status_code in (200, 202)
    except Exception:
        return False
