"""JUnit XML parser — supports standard JUnit/TestNG/Maven Surefire XML."""
import xml.etree.ElementTree as ET
from typing import List, Tuple
from app.schemas import TestCaseCreate, TestCaseStatusEnum


def parse_junit(content: bytes) -> Tuple[List[TestCaseCreate], float]:
    """Returns (test_cases, total_duration_seconds)."""
    root = ET.fromstring(content)

    # Handle both <testsuites> wrapper and direct <testsuite>
    if root.tag == "testsuites":
        suites = list(root.iter("testsuite"))
    elif root.tag == "testsuite":
        suites = [root]
    else:
        suites = list(root.iter("testsuite"))

    cases: List[TestCaseCreate] = []
    total_duration = 0.0

    for suite in suites:
        suite_time = float(suite.get("time", 0) or 0)
        total_duration += suite_time

        for tc in suite.findall("testcase"):
            name = tc.get("name", "Unknown")
            class_name = tc.get("classname")
            duration = float(tc.get("time", 0) or 0)

            failure = tc.find("failure")
            error = tc.find("error")
            skipped = tc.find("skipped")

            if skipped is not None:
                status = TestCaseStatusEnum.skipped
                error_message = None
                error_type = None
                stack_trace = None
            elif failure is not None:
                status = TestCaseStatusEnum.failed
                error_message = failure.get("message", "")
                error_type = failure.get("type", "")
                stack_trace = failure.text or ""
            elif error is not None:
                status = TestCaseStatusEnum.error
                error_message = error.get("message", "")
                error_type = error.get("type", "")
                stack_trace = error.text or ""
            else:
                status = TestCaseStatusEnum.passed
                error_message = None
                error_type = None
                stack_trace = None

            cases.append(TestCaseCreate(
                name=name,
                class_name=class_name,
                status=status,
                duration=duration,
                error_message=error_message,
                error_type=error_type,
                stack_trace=stack_trace,
            ))

    return cases, total_duration
