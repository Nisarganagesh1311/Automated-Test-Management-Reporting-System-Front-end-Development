"""Playwright JSON report parser — expects output from @playwright/test JSON reporter."""
import json
from typing import List, Tuple
from app.schemas import TestCaseCreate, TestCaseStatusEnum


def parse_playwright(content: bytes) -> Tuple[List[TestCaseCreate], float]:
    """Returns (test_cases, total_duration_seconds)."""
    data = json.loads(content)

    cases: List[TestCaseCreate] = []
    total_duration_ms = 0.0

    def process_suite(suite: dict):
        nonlocal total_duration_ms

        # Process tests in this suite
        for test in suite.get("tests", []):
            title = test.get("title", "Unknown")
            file_path = suite.get("file") or suite.get("title", "")
            status_raw = test.get("status", "passed")  # passed | failed | skipped | timedOut

            # Sum durations from all results (last result = final attempt)
            results = test.get("results", [])
            duration_ms = sum(r.get("duration", 0) for r in results)
            total_duration_ms += duration_ms

            status_map = {
                "passed": TestCaseStatusEnum.passed,
                "failed": TestCaseStatusEnum.failed,
                "skipped": TestCaseStatusEnum.skipped,
                "timedOut": TestCaseStatusEnum.error,
                "interrupted": TestCaseStatusEnum.error,
                "unexpected": TestCaseStatusEnum.failed,
                "flaky": TestCaseStatusEnum.failed,
            }
            status = status_map.get(status_raw, TestCaseStatusEnum.error)

            error_message = None
            stack_trace = None

            if results:
                last_result = results[-1]
                errors = last_result.get("errors", [])
                if errors:
                    err = errors[0]
                    error_message = err.get("message", "")
                    stack_trace = err.get("stack", "")

            cases.append(TestCaseCreate(
                name=title,
                class_name=suite.get("title"),
                file_path=file_path,
                status=status,
                duration=duration_ms / 1000.0,
                error_message=error_message,
                stack_trace=stack_trace,
            ))

        # Recurse into nested suites
        for child in suite.get("suites", []):
            process_suite(child)

    for suite in data.get("suites", []):
        process_suite(suite)

    return cases, total_duration_ms / 1000.0
