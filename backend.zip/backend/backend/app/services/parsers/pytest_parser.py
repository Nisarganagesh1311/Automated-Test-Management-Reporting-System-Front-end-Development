"""PyTest JSON report parser — expects output from pytest-json-report plugin."""
import json
from typing import List, Tuple
from app.schemas import TestCaseCreate, TestCaseStatusEnum


def parse_pytest(content: bytes) -> Tuple[List[TestCaseCreate], float]:
    """Returns (test_cases, total_duration_seconds)."""
    data = json.loads(content)

    cases: List[TestCaseCreate] = []
    total_duration = float(data.get("duration", 0))

    for test in data.get("tests", []):
        node_id: str = test.get("nodeid", "Unknown")
        outcome: str = test.get("outcome", "passed")
        duration = float(test.get("duration", 0))

        # Split nodeid into file path and test name
        parts = node_id.rsplit("::", 1)
        file_path = parts[0] if len(parts) == 2 else None
        name = parts[-1]

        # Map pytest outcomes
        status_map = {
            "passed": TestCaseStatusEnum.passed,
            "failed": TestCaseStatusEnum.failed,
            "skipped": TestCaseStatusEnum.skipped,
            "error": TestCaseStatusEnum.error,
            "xfailed": TestCaseStatusEnum.skipped,
            "xpassed": TestCaseStatusEnum.passed,
        }
        status = status_map.get(outcome, TestCaseStatusEnum.error)

        error_message = None
        error_type = None
        stack_trace = None

        call_info = test.get("call") or test.get("setup") or {}
        if call_info and "longrepr" in call_info:
            longrepr = call_info["longrepr"]
            if isinstance(longrepr, str):
                stack_trace = longrepr
                lines = longrepr.strip().split("\n")
                error_message = lines[-1] if lines else longrepr
            elif isinstance(longrepr, dict):
                error_message = longrepr.get("reprcrash", {}).get("message", "")
                stack_trace = str(longrepr)

        cases.append(TestCaseCreate(
            name=name,
            class_name=None,
            file_path=file_path,
            status=status,
            duration=duration,
            error_message=error_message,
            error_type=error_type,
            stack_trace=stack_trace,
        ))

    return cases, total_duration
