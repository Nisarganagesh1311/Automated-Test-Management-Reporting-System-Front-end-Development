"""Notification testing endpoints."""
from fastapi import APIRouter, HTTPException
from app.schemas import NotificationTestRequest
from app.services.notification_service import send_slack_notification, send_teams_notification

router = APIRouter(prefix="/api/notifications", tags=["notifications"])


@router.post("/test")
async def test_notification(body: NotificationTestRequest):
    if body.type == "slack":
        ok = await send_slack_notification(
            test_run_name="🧪 Test Notification",
            total=100, passed=95, failed=3, skipped=2,
            run_id="test-run-id",
            webhook_url=body.webhook_url,
        )
    else:
        ok = await send_teams_notification(
            test_run_name="🧪 Test Notification",
            total=100, passed=95, failed=3, skipped=2,
            run_id="test-run-id",
            webhook_url=body.webhook_url,
        )

    if not ok:
        raise HTTPException(status_code=502, detail="Failed to send notification. Check webhook URL.")
    return {"success": True, "message": f"{body.type.capitalize()} notification sent successfully."}
