"""CRUD routes for test runs and their test cases."""
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func, delete
from sqlalchemy.orm import selectinload
from typing import List, Optional

from app.database import get_db
from app.models import TestRun, TestCase
from app.schemas import TestRunRead, TestRunDetail, TestCaseRead

router = APIRouter(prefix="/api/test-runs", tags=["test-runs"])


@router.get("", response_model=dict)
async def list_test_runs(
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=100),
    project: Optional[str] = Query(None),
    status: Optional[str] = Query(None),
    db: AsyncSession = Depends(get_db),
):
    query = select(TestRun).order_by(TestRun.created_at.desc())

    if project:
        query = query.where(TestRun.project == project)
    if status:
        query = query.where(TestRun.status == status)

    # Count total
    count_query = select(func.count()).select_from(query.subquery())
    total_result = await db.execute(count_query)
    total = total_result.scalar() or 0

    # Paginate
    offset = (page - 1) * page_size
    query = query.offset(offset).limit(page_size)
    result = await db.execute(query)
    runs = result.scalars().all()

    return {
        "items": [TestRunRead.model_validate(r) for r in runs],
        "total": total,
        "page": page,
        "page_size": page_size,
        "total_pages": max(1, -(-total // page_size)),  # ceiling division
    }


@router.get("/{run_id}", response_model=TestRunDetail)
async def get_test_run(run_id: str, db: AsyncSession = Depends(get_db)):
    result = await db.execute(
        select(TestRun).options(selectinload(TestRun.test_cases)).where(TestRun.id == run_id)
    )
    run = result.scalar_one_or_none()
    if not run:
        raise HTTPException(status_code=404, detail="Test run not found")
    return run


@router.get("/{run_id}/cases", response_model=List[TestCaseRead])
async def get_test_cases(
    run_id: str,
    status: Optional[str] = Query(None),
    db: AsyncSession = Depends(get_db),
):
    query = select(TestCase).where(TestCase.test_run_id == run_id)
    if status:
        query = query.where(TestCase.status == status)
    query = query.order_by(TestCase.status, TestCase.name)
    result = await db.execute(query)
    return result.scalars().all()


@router.delete("/{run_id}", status_code=204)
async def delete_test_run(run_id: str, db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(TestRun).where(TestRun.id == run_id))
    run = result.scalar_one_or_none()
    if not run:
        raise HTTPException(status_code=404, detail="Test run not found")
    await db.execute(delete(TestCase).where(TestCase.test_run_id == run_id))
    await db.delete(run)
    await db.commit()
