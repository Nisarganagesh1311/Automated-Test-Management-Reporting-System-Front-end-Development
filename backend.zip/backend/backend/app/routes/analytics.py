"""Analytics routes — dashboard summary, failure trends, flaky tests."""
from fastapi import APIRouter, Depends, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func, case
from datetime import datetime, timedelta
from typing import List, Optional

from app.database import get_db
from app.models import TestRun, TestCase, TestRunStatus
from app.schemas import AnalyticsSummary, TrendPoint, FlakyTest

router = APIRouter(prefix="/api/analytics", tags=["analytics"])


@router.get("/summary", response_model=AnalyticsSummary)
async def get_summary(db: AsyncSession = Depends(get_db)):
    result = await db.execute(
        select(
            func.count(TestRun.id).label("total_runs"),
            func.coalesce(func.sum(TestRun.total_tests), 0).label("total_tests"),
            func.coalesce(func.sum(TestRun.passed_tests), 0).label("total_passed"),
            func.coalesce(func.avg(TestRun.duration), 0).label("avg_duration"),
        )
    )
    row = result.one()

    today_start = datetime.utcnow().replace(hour=0, minute=0, second=0, microsecond=0)
    failed_today_result = await db.execute(
        select(func.count(TestRun.id)).where(
            TestRun.status == TestRunStatus.failed,
            TestRun.created_at >= today_start,
        )
    )
    failed_today = failed_today_result.scalar() or 0

    total_tests = int(row.total_tests or 0)
    total_passed = int(row.total_passed or 0)
    pass_rate = round((total_passed / total_tests * 100) if total_tests > 0 else 0.0, 2)

    return AnalyticsSummary(
        total_runs=row.total_runs or 0,
        total_tests=total_tests,
        overall_pass_rate=pass_rate,
        average_duration=round(float(row.avg_duration or 0), 2),
        failed_runs_today=failed_today,
    )


@router.get("/trends", response_model=List[TrendPoint])
async def get_trends(
    days: int = Query(30, ge=1, le=365),
    project: Optional[str] = Query(None),
    db: AsyncSession = Depends(get_db),
):
    since = datetime.utcnow() - timedelta(days=days)

    query = (
        select(
            func.date(TestRun.created_at).label("date"),
            func.coalesce(func.sum(TestRun.passed_tests), 0).label("passed"),
            func.coalesce(func.sum(TestRun.failed_tests), 0).label("failed"),
            func.coalesce(func.sum(TestRun.skipped_tests), 0).label("skipped"),
            func.coalesce(func.sum(TestRun.total_tests), 0).label("total"),
        )
        .where(TestRun.created_at >= since)
        .group_by(func.date(TestRun.created_at))
        .order_by(func.date(TestRun.created_at))
    )

    if project:
        query = query.where(TestRun.project == project)

    result = await db.execute(query)
    rows = result.all()

    return [
        TrendPoint(
            date=str(row.date),
            passed=int(row.passed),
            failed=int(row.failed),
            skipped=int(row.skipped),
            total=int(row.total),
        )
        for row in rows
    ]


@router.get("/flaky", response_model=List[FlakyTest])
async def get_flaky_tests(
    min_runs: int = Query(3, ge=1),
    limit: int = Query(20, ge=1, le=100),
    db: AsyncSession = Depends(get_db),
):
    """Tests that appeared both as passed and failed across multiple runs."""
    sub = (
        select(
            TestCase.name,
            TestCase.class_name,
            func.count(TestCase.id).label("total_runs"),
            func.sum(case((TestCase.status == "failed", 1), else_=0)).label("failure_count"),
        )
        .group_by(TestCase.name, TestCase.class_name)
        .having(func.count(TestCase.id) >= min_runs)
        .subquery()
    )

    result = await db.execute(
        select(sub)
        .where(sub.c.failure_count > 0)
        .order_by(sub.c.failure_count.desc())
        .limit(limit)
    )
    rows = result.all()

    return [
        FlakyTest(
            name=row.name,
            class_name=row.class_name,
            failure_count=int(row.failure_count),
            total_runs=int(row.total_runs),
            failure_rate=round(row.failure_count / row.total_runs * 100, 1),
        )
        for row in rows
    ]


@router.get("/projects", response_model=List[str])
async def get_projects(db: AsyncSession = Depends(get_db)):
    result = await db.execute(
        select(TestRun.project).where(TestRun.project.isnot(None)).distinct()
    )
    return [row[0] for row in result.all()]
