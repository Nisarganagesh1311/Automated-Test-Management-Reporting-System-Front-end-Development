from fastapi import APIRouter, UploadFile, File, Form, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from typing import Optional
import uuid

from app.database import get_db
from app.models import TestRun, TestCase, TestRunStatus, TestSourceType, TestCaseStatus
from app.schemas import TestRunRead, TestSourceTypeEnum, TestCaseStatusEnum
from app.services.parsers import parse_junit, parse_pytest, parse_playwright
from app.services.ai_service import generate_failure_summary
from app.services.notification_service import send_slack_notification, send_teams_notification

router = APIRouter(prefix="/api/upload", tags=["upload"])

MAX_FILE_SIZE = 20 * 1024 * 1024  # 20 MB


@router.post("", response_model=TestRunRead)
async def upload_test_results(
    file: UploadFile = File(...),
    name: Optional[str] = Form(None),
    project: Optional[str] = Form(None),
    branch: Optional[str] = Form(None),
    commit_hash: Optional[str] = Form(None),
    source_type: str = Form("junit"),
    notify_slack: bool = Form(False),
    notify_teams: bool = Form(False),
    db: AsyncSession = Depends(get_db),
):
    content = await file.read()

    if len(content) > MAX_FILE_SIZE:
        raise HTTPException(status_code=413, detail="File too large (max 20MB)")

    run_name = name or (file.filename or "Unnamed Run")

    # Parse based on source type
    try:
        src = TestSourceTypeEnum(source_type)
        if src == TestSourceTypeEnum.junit:
            cases_data, duration = parse_junit(content)
        elif src == TestSourceTypeEnum.pytest:
            cases_data, duration = parse_pytest(content)
        elif src == TestSourceTypeEnum.playwright:
            cases_data, duration = parse_playwright(content)
        else:
            raise HTTPException(status_code=400, detail=f"Unsupported source type: {source_type}")
    except (ValueError, Exception) as exc:
        raise HTTPException(status_code=422, detail=f"Failed to parse file: {str(exc)}")

    # Aggregate counts
    total = len(cases_data)
    passed = sum(1 for c in cases_data if c.status == TestCaseStatusEnum.passed)
    failed = sum(1 for c in cases_data if c.status == TestCaseStatusEnum.failed)
    skipped = sum(1 for c in cases_data if c.status == TestCaseStatusEnum.skipped)
    errors = sum(1 for c in cases_data if c.status == TestCaseStatusEnum.error)

    overall_status = TestRunStatus.passed if (failed + errors) == 0 else TestRunStatus.failed

    # Create test run record
    run = TestRun(
        id=str(uuid.uuid4()),
        name=run_name,
        project=project,
        branch=branch,
        commit_hash=commit_hash,
        source_type=TestSourceType(source_type),
        status=overall_status,
        total_tests=total,
        passed_tests=passed,
        failed_tests=failed,
        skipped_tests=skipped,
        error_tests=errors,
        duration=duration,
    )
    db.add(run)
    await db.flush()

    # Bulk insert test cases
    for c in cases_data:
        db.add(TestCase(
            id=str(uuid.uuid4()),
            test_run_id=run.id,
            name=c.name,
            class_name=c.class_name,
            file_path=c.file_path,
            status=TestCaseStatus(c.status.value),
            duration=c.duration,
            error_message=c.error_message,
            error_type=c.error_type,
            stack_trace=c.stack_trace,
        ))

    # Generate AI summary for failures
    if failed + errors > 0:
        failed_cases = [c for c in cases_data if c.status in (TestCaseStatusEnum.failed, TestCaseStatusEnum.error)]
        run.ai_summary = await generate_failure_summary(run_name, failed_cases)

    await db.commit()
    await db.refresh(run)

    run_id_str = str(run.id)

    # Send notifications asynchronously (fire-and-forget style)
    if notify_slack:
        await send_slack_notification(run_name, total, passed, failed, skipped, run_id_str)
    if notify_teams:
        await send_teams_notification(run_name, total, passed, failed, skipped, run_id_str)

    return run
