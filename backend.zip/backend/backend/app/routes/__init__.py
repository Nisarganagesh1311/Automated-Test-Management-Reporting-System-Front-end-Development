from app.routes import upload, test_runs, analytics, notifications

__all__ = ["upload", "test_runs", "analytics", "notifications"]
